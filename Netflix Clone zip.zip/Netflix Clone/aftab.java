public class addition {
	void add(int n1, int n2)
	{
		int s = n1+n2;
		System.out.println("sum = "+s);
	}
	void add(float n1, float n2)
	{
		float s = n1+n2;
		System.out.println("sum = "+s);
	}w
	void add(double n1, double n2)
	{
		double s = n1+n2;
		System.out.println("sum = "+s);
	}
	void add(char n1, char n2)
	{
		char s = n1+n2;
		System.out.println("sum = "+s);
	}

	public static void main(string[] args) {

		OverloadingExample obj = new OverloadingExample();
		System.out.println("sum of two numbers: " +obj.add(a:10, b:20));
		System.out.println("concatenation of two strings: " +obj.add(s1:"Hello", s2:"World"));
		char a = 'A';
		char b = 'B';
		System.out.println("Concatenation of two char: " +obj.add(a, b));
	}
}

